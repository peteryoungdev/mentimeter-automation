@echo off
echo Iniciando automacao Mentimeter...

:: Verifica se a pasta node_modules existe
if not exist "node_modules\" (
    echo Instalando dependencias (npm install)...
    call npm install
)

:: Verifica se os navegadores do Playwright estao instalados
echo Verificando navegadores do Playwright...
call npx playwright install chromium

:: Executa o script
echo Executando o script...
node index.js

echo.
echo Processo concluido ou interrompido.
pause
