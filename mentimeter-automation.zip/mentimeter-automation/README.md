# Mentimeter Automation Script

Este projeto automatiza a entrada no site `menti.com` usando um código de aula e captura dados de sessão para análise.

## Pré-requisitos

- [Node.js](https://nodejs.org/) instalado.
- Playwright (já incluído no projeto).

## Como Executar

### Opção 1: Usando o arquivo .bat (Mais fácil no Windows)
1. Basta dar um duplo clique no arquivo `run.bat` na pasta do projeto.
2. Ele vai verificar as dependências e rodar o script automaticamente.

### Opção 2: Via Terminal
1. Abra o terminal na pasta do projeto.
2. Execute o comando:
   ```bash
   node index.js
   ```

## O que o script faz?

1. Abre o navegador (Chromium).
2. Vai para `menti.com`.
3. Insere o código `72608269`.
4. Clica em "Join".
5. Aguarda o carregamento e captura:
   - Cookies
   - Local Storage
   - Session Storage
6. Salva tudo em um arquivo chamado `session_data.json`.
7. Mantém o navegador aberto por 30 segundos para você visualizar a página.

## Analisando Dados de Usuário

Após a execução, abra o arquivo `session_data.json` para ver quais informações o site armazenou no seu navegador durante o processo.
