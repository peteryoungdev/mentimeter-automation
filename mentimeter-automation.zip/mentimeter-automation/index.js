const { chromium } = require('playwright');

(async () => {
    const browser = await chromium.launch({ headless: false });
    const code = '72608269';
    const numberOfUsers = 5; // Altere este número para abrir mais ou menos abas

    console.log(`Iniciando automação para ${numberOfUsers} usuários...`);

    for (let i = 1; i <= numberOfUsers; i++) {
        console.log(`[Usuário ${i}] Abrindo nova aba...`);
        
        // Criar um novo contexto para cada usuário (cookies independentes)
        const context = await browser.newContext();
        const page = await context.newPage();

        await page.goto('https://www.menti.com');

        console.log(`[Usuário ${i}] Inserindo código...`);
        const inputSelector = 'input[aria-label="Please enter the 7 or 8 digit code"]';
        await page.waitForSelector(inputSelector);
        await page.fill(inputSelector, code);

        await page.click('button:has-text("Join")');
        console.log(`[Usuário ${i}] Participando da apresentação.`);

        // Pequeno delay entre abrir cada aba para não sobrecarregar
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    console.log('Todos os usuários entraram. Mantendo o navegador aberto...');
    // O navegador ficará aberto para você interagir
})();

